# VELOCHESS owner setup

The public site is https://velochess.grainyflour1.chatgpt.site.
Email/password accounts, ratings, matchmaking, friends, messages and room state use the D1 binding `DB`. Account sessions are stored in secure HttpOnly cookies; passwords use salted scrypt (N=32768, r=8, p=3). No passwords or session tokens are placed in browser localStorage. Apply the tracked Drizzle migrations through the Sites deployment workflow.

## Google sign-in

Native Google sign-in is deliberately unavailable until the owner configures a Google OAuth web client:

1. Create a Google Cloud project, configure the OAuth consent screen and an OAuth 2.0 client of type Web application.
2. Add `https://velochess.grainyflour1.chatgpt.site` as an authorized JavaScript origin. Once the custom domain is active, also add `https://velochess.com`.
3. Configure the Site runtime variable `GOOGLE_CLIENT_ID` with that web client ID and deploy a new version. Google Identity Services uses a nonce-bound credential response; this application does not need a client secret or an OAuth callback route.
4. Publish the Google consent screen as appropriate for its audience. The application verifies Google's signature, issuer, audience, expiration, verified email and one-use nonce on the server.

Email/password registration works independently. A newly created Google profile must choose a unique username before using community features. Existing email/password accounts are not silently linked to Google merely because an email matches.

## velochess.com domain

A custom-domain association has been prepared and is pending DNS verification. The owner must own/control this domain. At its DNS provider set these records:

| Type | Name | Value |
|---|---|---|
| A | @ | 162.159.143.30 |
| A | @ | 172.66.3.26 |
| TXT | _openai-site-verification | openai-site-verification=CN4_2v1HJY3ZMf0gKkKeJlDPJ_tPR74KtB4uP7eh6JU |
| TXT | _cf-custom-hostname | 437c2c71-06f7-43de-8b49-366d7923bc7e |

Preserve unrelated mail/verification records. Remove conflicting A/AAAA records for the root hostname only after checking the intended cutover. Refresh the Sites custom-domain status after the records propagate. The domain does not route to VELOCHESS until validation and TLS issuance succeed.

The site includes a crawlable title, description, canonical URL, robots.txt and sitemap.xml. Search-engine crawling and ranking are external and are not immediate or guaranteed. After the custom domain becomes active, update the canonical URL and sitemap to it and submit it through the owner's Google Search Console if desired.

## Ratings and reconnect rules

New profiles start at 800. Their first five rated results use K=64 expected-score adjustments; draws always change rating by zero. Subsequent results use ±8 for a gap up to 50, +7/−9 for the higher-rated player and +9/−7 for the lower-rated player for a 51–100 gap, and K=16 expected-score changes clamped to 1–15 for larger gaps. Ratings have a floor of 100. The rating ledger and profile updates commit atomically once per completed rated game.

Reconnect grace is 10 seconds for 1-minute controls, 15 for 3-minute, 20 for 5-minute, and 30 for slower controls. A five-second heartbeat tolerance precedes a network-disconnection countdown. Explicit tab/window abandonment starts the grace immediately. The game clock continues. Both players exceeding their deadlines yields a draw.

Premoves are off by default. Up to ten are queued and validated on execution by the server. Each legal premove deducts 10 ms and receives the configured increment. Invalid premoves clear the remaining queue. Move review is a notation/board replay, without an engine accuracy score.
