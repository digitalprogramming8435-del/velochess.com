import {readdir,readFile,mkdir,writeFile} from 'node:fs/promises';
import {dirname,resolve,relative,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {deflateRawSync} from 'node:zlib';

const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const DIRECTORIES=['public','server','scripts','tests','db','drizzle','migrations'];
const TOP_FILES=['package.json','package-lock.json','README.md','SETUP.md','.gitignore','drizzle.config.js'];
const EXCLUDED_NAMES=new Set(['node_modules','work','dist','outputs','.git','.openai','.sites-runtime','.wrangler','sync-source.mjs']);
const BINARY_SECRET_EXTENSIONS=new Set(['.key','.pem','.p12','.pfx','.keystore']);
const GUIDE=`# VELOCHESS source download\n\nThis archive includes the chess application, twelve piece sets, ten recorded wooden sound packs, account and community APIs, rated matchmaking, multiple premoves, tests and database migrations.\n\nPlay now: https://velochess.grainyflour1.chatgpt.site\n\nInstall Node.js 22+ and run npm ci, npm test, then npm run build in the extracted velochess folder. The build generates a Cloudflare Worker in dist/server/index.js and a self-contained offline HTML for in-person chess. Online accounts and play require the server and D1 binding DB.\n\nSee SETUP.md for Google sign-in, custom-domain DNS, ratings, reconnect rules and deployment details. These external configurations are not automatically activated by downloading the source. The included hosting manifest omits the original project identity; create your own Site before deployment.\n\nSee public/LICENSES.md for artwork and recorded-audio licenses. Private account data, passwords, credentials, player sessions and the hosted database are not included.\n`;

const CRC_TABLE=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0});
function crc32(bytes){let crc=0xffffffff;for(const byte of bytes)crc=CRC_TABLE[(crc^byte)&255]^(crc>>>8);return(crc^0xffffffff)>>>0}
function eligible(name){return !EXCLUDED_NAMES.has(name)&&!name.startsWith('.')&&!/^\.env(?:\.|$)/i.test(name)&&!BINARY_SECRET_EXTENSIONS.has(extname(name).toLowerCase())&&!/^(?:credentials|secrets?)(?:\.|$)/i.test(name)}
async function collect(directory,files){let entries;try{entries=await readdir(resolve(ROOT,directory),{withFileTypes:true})}catch(error){if(error.code==='ENOENT')return;throw error}for(const entry of entries){if(!eligible(entry.name))continue;const path=directory+'/'+entry.name;if(entry.isDirectory())await collect(path,files);else if(entry.isFile())files.push(path)}}

/** Returns a self-contained source ZIP. Reads an explicit allowlist; never uses Git or runtime state. */
export async function packageSource(){
  const paths=[...TOP_FILES];for(const directory of DIRECTORIES)await collect(directory,paths);
  const entries=[];
  for(const path of [...new Set(paths)].sort()){
    let bytes;try{bytes=await readFile(resolve(ROOT,path))}catch(error){if(error.code==='ENOENT')continue;throw error}
    // The downloadable validator must validate a newly imported project, not the original site's ID.
    if(path==='scripts/validate.mjs')bytes=Buffer.from(bytes.toString('utf8').replace(/assert\.equal\(manifest\.project_id,\s*(['"])[^'"]+\1\);?/g,''));
    entries.push({path,bytes});
  }
  let manifest={d1:'DB',r2:null};try{manifest=JSON.parse(await readFile(resolve(ROOT,'.openai/hosting.json'),'utf8'))}catch(error){if(error.code!=='ENOENT')throw error}
  delete manifest.project_id;
  entries.push({path:'.openai/hosting.json',bytes:Buffer.from(JSON.stringify(manifest,null,2)+'\n')},{path:'DOWNLOADING.md',bytes:Buffer.from(GUIDE)});
  entries.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
  if(entries.length>65535)throw Error('Source ZIP has too many files');
  const locals=[],centrals=[];let offset=0;
  for(const entry of entries){
    const name=Buffer.from('velochess/'+entry.path),raw=entry.bytes,compressed=deflateRawSync(raw,{level:9}),crc=crc32(raw);
    const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50,0);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt32LE(crc,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(raw.length,22);local.writeUInt16LE(name.length,26);
    const central=Buffer.alloc(46);central.writeUInt32LE(0x02014b50,0);central.writeUInt16LE(0x0314,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x800,8);central.writeUInt16LE(8,10);central.writeUInt16LE(33,14);central.writeUInt32LE(crc,16);central.writeUInt32LE(compressed.length,20);central.writeUInt32LE(raw.length,24);central.writeUInt16LE(name.length,28);central.writeUInt32LE((0o100644<<16)>>>0,38);central.writeUInt32LE(offset,42);
    locals.push(local,name,compressed);centrals.push(central,name);offset+=local.length+name.length+compressed.length;
  }
  const directory=Buffer.concat(centrals),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
  const zip=Buffer.concat([...locals,directory,end]);if(zip.length>32*1024*1024)throw Error('Source ZIP exceeds 32 MiB');return new Uint8Array(zip);
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const zip=await packageSource(),target=resolve(ROOT,'work/downloads/rook-chess-source.zip');
  await mkdir(dirname(target),{recursive:true});await writeFile(target,zip);console.log('Created '+relative(ROOT,target)+' ('+zip.length+' bytes)');
}
