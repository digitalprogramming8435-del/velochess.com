import {build} from 'esbuild';
import {readFile} from 'node:fs/promises';
export async function buildOffline(){
 const bundle=await build({entryPoints:['public/app.js'],bundle:true,write:false,format:'iife',minify:true,target:'es2022',legalComments:'inline',plugins:[{name:'offline-mode',setup(b){b.onLoad({filter:/public\/app\.js$/},async args=>{let source=await readFile(args.path,'utf8');source=source.replace('async function api(url,data,token=online?.token){',`async function api(url,data,token=online?.token){throw new Error('Online games require the live site: https://velochess.grainyflour1.chatgpt.site');`);return{contents:source,loader:'js'}})}}]});
 let html=await readFile('public/index.html','utf8');const css=await readFile('public/style.css','utf8');const communityCss=await readFile('public/community.css','utf8');const license=await readFile('public/LICENSES.md','utf8');
 const licenseUrl='data:text/plain;charset=utf-8;base64,'+Buffer.from(license).toString('base64');
 const js=bundle.outputFiles[0].text.replaceAll('/LICENSES.md',licenseUrl).replace(/<\/script/gi,'<\\/script');
 html=html.replace(/<link rel="preconnect"[^>]*>/g,'').replace(/<link href="https:\/\/fonts\.googleapis\.com[^>]*>/g,'').replace('<link rel="stylesheet" href="/style.css">',`<style>${css}</style>`).replace('<link rel="stylesheet" href="/community.css">',`<style>${communityCss}</style>`).replace('href="/" aria-label="VELOCHESS home"','href="#" aria-label="VELOCHESS home"').replace('<script type="module" src="/app.js"></script>',`<script>${js}</script>`);
 html=html.replace('<title>VELOCHESS — Play chess online</title>','<title>VELOCHESS — Offline chess</title>');
 return html;
}
