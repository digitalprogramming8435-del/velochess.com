import {build} from 'esbuild';
import {readFile,writeFile,mkdir,cp,rm} from 'node:fs/promises';
import {buildOffline} from './offline.mjs';
import {packageSource} from './package-source.mjs';
await rm('dist',{recursive:true,force:true});
await mkdir('dist/server',{recursive:true});await mkdir('work/client',{recursive:true});await mkdir('work/downloads',{recursive:true});
await build({entryPoints:['public/app.js'],outfile:'work/client/app.js',bundle:true,format:'esm',minify:true,target:'es2022',legalComments:'inline'});
const files={};for(const name of ['index.html','style.css','community.css','LICENSES.md','pieces.js','audio-data.js'])files['/'+name]=await readFile('public/'+name,'utf8');files['/app.js']=await readFile('work/client/app.js','utf8');
await writeFile('work/assets.js','export default '+JSON.stringify(files)+';');
const offline=await buildOffline();await writeFile('work/downloads/rook-chess.html',offline);
const source=await packageSource();await writeFile('work/downloads/rook-chess-source.zip',source);
await writeFile('work/downloads.js','export default '+JSON.stringify({'/downloads/velochess.html':{name:'velochess.html',type:'text/html; charset=utf-8',base64:Buffer.from(offline).toString('base64')},'/downloads/velochess-smooth-mobile.zip':{name:'velochess-smooth-mobile.zip',type:'application/zip',base64:Buffer.from(source).toString('base64')},'/downloads/velochess-fast-matching.zip':{name:'velochess-fast-matching.zip',type:'application/zip',base64:Buffer.from(source).toString('base64')},'/downloads/velochess-original-audio.zip':{name:'velochess-original-audio.zip',type:'application/zip',base64:Buffer.from(source).toString('base64')},'/downloads/velochess-source.zip':{name:'velochess-source.zip',type:'application/zip',base64:Buffer.from(source).toString('base64')},'/downloads/rook-chess.html':{name:'rook-chess.html',type:'text/html; charset=utf-8',base64:Buffer.from(offline).toString('base64')},'/downloads/rook-chess-source.zip':{name:'rook-chess-source.zip',type:'application/zip',base64:Buffer.from(source).toString('base64')}})+';');
await build({entryPoints:['server/worker.js'],outfile:'dist/server/index.js',bundle:true,format:'esm',target:'es2022',minify:true});
await mkdir('dist/.openai',{recursive:true});await cp('.openai/hosting.json','dist/.openai/hosting.json');
try{await cp('drizzle','dist/drizzle',{recursive:true})}catch{}
console.log('Built VELOCHESS: Worker, frontend, artwork, offline HTML and source ZIP.');
