import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {parseHTML} from 'linkedom';

const alpha={id:'alpha',email:'alpha@example.invalid',username:'Alpha.Player',rating:800,gamesPlayed:0,provisional:true};
const beta={id:'beta',email:'beta@example.invalid',username:'Beta.Player',rating:810,gamesPlayed:5,provisional:false};
const emptyFriends={friends:[],requests:[],sent:[]};
const response=data=>({ok:true,status:200,json:async()=>data});
function deferred(){let resolve;const promise=new Promise(done=>{resolve=done});return{promise,resolve:data=>resolve(response(data))}}
const flush=()=>new Promise(resolve=>setImmediate(resolve));
function harness(fetcher){
 const {window,document}=parseHTML(readFileSync(new URL('../public/index.html',import.meta.url),'utf8'));
 const intervals=new Map(),connections=[];let timerId=0,currentGame=null;
 window.HTMLElement.prototype.focus=function(){};
 const $=s=>document.querySelector(s);
 function closeModal(){const root=$('#modalRoot'),cancel=root._onClose;delete root._onClose;root.innerHTML='';cancel?.()}
 function modal(html){const root=$('#modalRoot'),cancel=root._onClose;delete root._onClose;cancel?.();root.innerHTML=html}
 const context=vm.createContext({window,document,console,location:{protocol:'https:'},Date,JSON,Promise,fetch:fetcher,modal,closeModal,connectRoom(game){connections.push(game);currentGame={online:{code:game.code},remote:{status:'active'}}},getGame(){return currentGame},toast(){},setTimeout(){return++timerId},clearTimeout(){},setInterval(fn,ms){const id=++timerId;intervals.set(id,{fn,ms});return id},clearInterval(id){intervals.delete(id)}});
 vm.runInContext(readFileSync(new URL('../public/community.js',import.meta.url),'utf8').replace('export function initCommunity','function initCommunity'),context);
 vm.runInContext('var community=initCommunity({modal,closeModal,toast,connectRoom,getGame});',context);
 return{document,$,connections,setFetch(fn){context.fetch=fn},run:code=>vm.runInContext(code,context),async login(user){context.loginEmail=user.email;context.loginPassword='A long private password';vm.runInContext('community.openAccount()',context);$('#authEmail').value=user.email;$('#authPassword').value=context.loginPassword;await $('#authForm').onsubmit({preventDefault(){}})},async logout(){vm.runInContext('community.openAccount()',context);await $('#signOut').onclick()},tick(ms){for(const timer of [...intervals.values()])if(timer.ms===ms)timer.fn()}};
}

test('a late initial account lookup cannot replace a successful login with signed-out UI',async()=>{
 const initial=deferred();
 const a=harness(async path=>path==='/api/auth/me'?initial.promise:response(path==='/api/auth/login'?{user:alpha}:path==='/api/auth/config'?{googleClientId:null}:path==='/api/social/friends'?emptyFriends:{}));
 await a.login(alpha);assert.equal(a.run('community.user.id'),'alpha');
 initial.resolve({user:null});await flush();
 assert.equal(a.run('community.user.id'),'alpha');assert.match(a.$('#accountButton').textContent,/Alpha.Player/);
});

test('a delayed profile refresh cannot restore an account after explicit sign-out',async()=>{
 const delayed=deferred();let reads=0;
 const a=harness(async path=>path==='/api/auth/me'?(++reads===1?response({user:alpha}):delayed.promise):response(path==='/api/social/friends'?emptyFriends:{}));
 await flush();const pending=a.run('community.refresh()');await a.logout();assert.equal(a.run('community.user'),null);
 delayed.resolve({user:alpha});await pending;
 assert.equal(a.run('community.user'),null);assert.equal(a.$('#accountButton').textContent,'Sign in');
});

test('friend responses from the previous account cannot repaint friends or notifications',async()=>{
 const oldFriends=deferred();let friendReads=0;
 const betaFriends={friends:[{id:'beta-friend',username:'Beta.Friend',rating:820}],requests:[],sent:[]};
 const a=harness(async path=>response(path==='/api/auth/me'?{user:alpha}:path==='/api/auth/login'?{user:beta}:path==='/api/auth/config'?{googleClientId:null}:path==='/api/social/friends'?emptyFriends:{}));
 // A deferred request starts before switching identities.
 await flush();
 const controlled=async path=>path==='/api/social/friends'?(++friendReads===1?oldFriends.promise:response(betaFriends)):response(path==='/api/auth/login'?{user:beta}:path==='/api/auth/config'?{googleClientId:null}:{});
 a.setFetch(controlled);
 a.tick(6000);await a.logout();await a.login(beta);await flush();
 const opened=a.run('community.openFriends()');await opened;
 assert.match(a.$('#friendsPanel').textContent,/Beta.Friend/);
 oldFriends.resolve({friends:[{id:'alpha-friend',username:'Alpha.Friend',rating:900}],requests:[{id:'old-request',from:{id:'private-id',username:'Alpha.Request',rating:900},createdAt:1}],sent:[]});await flush();
 assert.match(a.$('#friendsPanel').textContent,/Beta.Friend/);assert.doesNotMatch(a.$('#friendsPanel').textContent,/Alpha.Friend/);
 assert.equal(a.$('.notification-count').hidden,true);assert.equal(a.document.querySelectorAll('.community-notification').length,0);
});

test('a pre-deletion chat response cannot bring a deleted message back onto the screen',async()=>{
 const oldPoll=deferred();let chatReads=0;
 const message={id:'message-one',senderId:'alpha',text:'Private message body',createdAt:1,mine:true};
 const a=harness(async(path,options={})=>{
  if(path==='/api/auth/me')return response({user:alpha});
  if(path==='/api/social/friends')return response({friends:[{id:'beta',username:'Beta.Player',rating:810}],requests:[],sent:[]});
  if(path==='/api/social/chat/beta')return ++chatReads===1?response({messages:[message]}):chatReads===2?oldPoll.promise:response({messages:[{...message,text:null,deletedForEveryone:true}]});
  return response({ok:true});
 });
 await flush();await a.run("community.openChat('beta')");await flush();assert.match(a.$('#chatMessages').textContent,/Private message body/);
 a.tick(1500);const deletion=a.$('[data-delete-message][data-scope="everyone"]').onclick();await deletion;
 assert.match(a.$('#chatMessages').textContent,/Message deleted/);
 oldPoll.resolve({messages:[message]});await flush();
 assert.match(a.$('#chatMessages').textContent,/Message deleted/);assert.doesNotMatch(a.$('#chatMessages').textContent,/Private message body/);
});


test('closing matchmaking while its POST is pending cleans the queue and does not reopen search',async()=>{
 const pendingPost=deferred(),calls=[];
 const a=harness(async(path,options={})=>{
  calls.push([path,options.method]);
  if(path==='/api/auth/me')return response({user:alpha});
  if(path==='/api/social/friends')return response(emptyFriends);
  if(path==='/api/matchmaking')return options.method==='POST'?pendingPost.promise:response({status:'cancelled'});
  return response({});
 });
 await flush();a.run('community.openOnline()');
 const finding=a.$('#findOpponent').onclick();
 a.run('closeModal()');
 await flush();assert.equal(a.$('#modalRoot').innerHTML,'');
 pendingPost.resolve({status:'waiting'});await finding;await flush();
 assert.equal(a.$('#modalRoot').innerHTML,'');
 assert.equal(a.$('#cancelSearch'),null);assert.equal(a.connections.length,0);
 assert.ok(calls.filter(([path,method])=>path==='/api/matchmaking'&&method==='DELETE').length>=1);
});

test('closing an in-flight matchmaking request reconnects an already committed match only once',async()=>{
 const pendingPost=deferred(),calls=[];
 const game={code:'ABCD2345',color:'w',state:{status:'active'}};
 const a=harness(async(path,options={})=>{
  calls.push([path,options.method]);
  if(path==='/api/auth/me')return response({user:alpha});
  if(path==='/api/social/friends')return response(emptyFriends);
  if(path==='/api/matchmaking')return options.method==='POST'?pendingPost.promise:response({status:'matched',game});
  return response({});
 });
 await flush();a.run('community.openOnline()');
 const finding=a.$('#findOpponent').onclick();
 a.run('closeModal()');await flush();
 assert.equal(a.connections.length,1);assert.equal(a.connections[0].code,game.code);
 pendingPost.resolve({status:'matched',game});await finding;await flush();
 assert.equal(a.connections.length,1);
 assert.equal(a.$('#modalRoot').innerHTML,'');
 assert.ok(calls.filter(([path,method])=>path==='/api/matchmaking'&&method==='DELETE').length>=2);
});
