import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { handleApi } from '../server/api.js';

// Real D1-compatible SQLite fixtures: online rooms now require signed-in accounts.
import {database} from './helpers/d1.js';
import {digest,randomHex} from '../server/http.js';
class MemoryD1 {
 constructor(){const db=database();this.prepare=db.prepare;this.batch=db.batch;this._sqlite=db._sqlite;this.rows={get:code=>{if(!db._sqlite.prepare('SELECT code FROM games WHERE code=?').get(code))return undefined;return Object.defineProperties({code},{data:{get:()=>db._sqlite.prepare('SELECT data FROM games WHERE code=?').get(code).data,set:value=>db._sqlite.prepare('UPDATE games SET data=? WHERE code=?').run(value,code)},revision:{get:()=>db._sqlite.prepare('SELECT revision FROM games WHERE code=?').get(code).revision}})}}}
}
async function account(env,name){const id=crypto.randomUUID(),token=randomHex();await env.DB.prepare('INSERT INTO users (id,email,email_verified,username,username_key,rating,games_played,rating_revision,created_at) VALUES (?,?,1,?,?,800,0,0,?)').bind(id,name.toLowerCase()+'@example.invalid',name,name.toLowerCase(),Date.now()).run();await env.DB.prepare('INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES (?,?,?,?)').bind(await digest(token),id,Date.now()+86400000,Date.now()).run();return '__Host-velo_session='+token}
async function api(env, path, { method = 'GET', data, token } = {}) {
  const session=token?.startsWith('__Host-velo_session=')?token:token?env.outsiderCookie:method==='POST'&&path==='/games'?env.hostCookie:method==='POST'&&path.endsWith('/join')?env.guestCookie:null;
  const response = await handleApi(new Request(`https://chess.test/api${path}`, {
    method, headers: { ...(session?{Cookie:session}:{}), ...(data ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: data ? JSON.stringify(data) : undefined,
  }), env);
  return { status: response.status, data: await response.json() };
}
async function room(control = '5+3', hostColor = 'w') {
  const env = { DB: new MemoryD1() };env.hostCookie=await account(env,'Host');env.guestCookie=await account(env,'Guest');env.outsiderCookie=await account(env,'Outsider');
  const host = (await api(env, '/games', { method: 'POST', data: { timeControl: control, color: hostColor, name: 'Host' } })).data;
  const guest = (await api(env, `/games/${host.code}/join`, { method: 'POST', data: { name: 'Guest' } })).data;
  host.token=env.hostCookie;guest.token=env.guestCookie;
  const token = color => color === host.color ? host.token : guest.token;
  const move = async (color, from, to, promotion) => api(env, `/games/${host.code}/action`, { method: 'POST', token: token(color), data: { type: 'move', from, to, promotion } });
  return { env, host, guest, token, move };
}
function setPosition(env, code, fen) {
  const row = env.DB.rows.get(code); const game = JSON.parse(row.data);
  const chess = new Chess(fen); game.pgn = chess.pgn(); row.data = JSON.stringify(game);
}

test('rooms create/join with private sessions and secret-free state', async () => {
  const { env, host, guest } = await room('10+0', 'b');
  assert.equal(host.color, 'b'); assert.equal(guest.color, 'w');
  assert.equal(host.state.status, 'waiting'); assert.equal(guest.state.status, 'active');
  assert.equal(guest.state.remaining.w, 600000); assert.ok(guest.state.activeSince);
  assert.ok(!JSON.stringify(guest.state).includes('tokenHash'));
  assert.equal((await api(env, `/games/${host.code}`, {})).status, 401);
  assert.equal((await api(env, `/games/${host.code}`, { token: 'a'.repeat(64) })).status, 403);
  assert.equal((await api(env, `/games/${host.code}/join`, { method: 'POST', data: {} })).status, 409);
});

test('legal turns, illegal moves, stale revision, increments and PGN history', async () => {
  const { env, host, move } = await room();
  assert.equal((await move('b', 'e7', 'e5')).status, 409);
  assert.equal((await move('w', 'e2', 'e5')).status, 422);
  let response = await move('w', 'e2', 'e4');
  assert.equal(response.status, 200); assert.equal(response.data.turn, 'b');
  assert.equal(response.data.moves[0].san, 'e4'); assert.ok(response.data.remaining.w > 302000);
  response = await api(env, `/games/${host.code}/action`, { method: 'POST', token: host.token, data: { type: 'resign', revision: 0 } });
  assert.equal(response.status, 409);
  assert.equal((await move('b', 'e7', 'e5')).data.moves.length, 2);
});

test('Fool’s mate ends with black win and no further moves', async () => {
  const { move } = await room();
  await move('w', 'f2', 'f3'); await move('b', 'e7', 'e5'); await move('w', 'g2', 'g4');
  const result = await move('b', 'd8', 'h4');
  assert.deepEqual(result.data.result, { winner: 'b', reason: 'checkmate' });
  assert.equal(result.data.status, 'ended');
  assert.equal((await move('w', 'e2', 'e4')).data.moves.length, 4);
});

test('en passant is applied to history and captured pawn removal', async () => {
  const { move } = await room();
  await move('w', 'e2', 'e4'); await move('b', 'a7', 'a6'); await move('w', 'e4', 'e5'); await move('b', 'd7', 'd5');
  const result = await move('w', 'e5', 'd6');
  assert.equal(result.data.moves.at(-1).flags, 'e');
  const chess = new Chess(result.data.fen); assert.equal(chess.get('d5'), undefined); assert.equal(chess.get('d6').color, 'w');
});

test('castling and explicit knight promotion survive stored PGN', async () => {
  let data = await room();
  setPosition(data.env, data.host.code, 'r3k2r/ppp2ppp/2n1bn2/3pp3/3PP3/2N1BN2/PPP2PPP/R3K2R w KQkq - 0 1');
  const castled = await data.move('w', 'e1', 'g1');
  assert.equal(castled.data.moves.at(-1).san, 'O-O'); assert.equal(new Chess(castled.data.fen).get('f1').type, 'r');
  data = await room();
  setPosition(data.env, data.host.code, '7k/P7/8/8/8/8/7p/4K3 w - - 0 1');
  const promoted = await data.move('w', 'a7', 'a8', 'n');
  assert.equal(new Chess(promoted.data.fen).get('a8').type, 'n');
});

test('stalemate, insufficient material and fifty-move draws', async () => {
  for (const [fen, from, to, reason] of [
    ['k7/8/1QK5/8/8/8/8/8 w - - 0 1', 'b6', 'c7', 'stalemate'],
    ['7k/8/8/8/8/8/3b4/4K3 w - - 0 1', 'e1', 'd2', 'insufficient'],
    ['7k/8/8/8/8/8/8/R3K3 w - - 99 1', 'a1', 'a2', 'fifty-move'],
  ]) {
    const { env, host, move } = await room(); setPosition(env, host.code, fen);
    const result = await move('w', from, to);
    assert.equal(result.status, 200); assert.deepEqual(result.data.result, { winner: null, reason });
  }
});

test('threefold repetition is detected from complete persisted PGN', async () => {
  const { move } = await room();
  let result;
  for (let i = 0; i < 2; i++) {
    await move('w', 'g1', 'f3'); await move('b', 'g8', 'f6'); await move('w', 'f3', 'g1'); result = await move('b', 'f6', 'g8');
  }
  assert.deepEqual(result.data.result, { winner: null, reason: 'repetition' });
});

test('draw offer persists through offering player move; opponent accepts', async () => {
  const { env, host, token, move } = await room();
  const act = (color, type) => api(env, `/games/${host.code}/action`, { method: 'POST', token: token(color), data: { type } });
  await act('w', 'offer-draw'); assert.equal((await move('w', 'e2', 'e4')).data.drawOffer, 'w');
  assert.equal((await act('w', 'accept-draw')).status, 409);
  assert.deepEqual((await act('b', 'accept-draw')).data.result, { winner: null, reason: 'agreement' });
});

test('timeout is server authoritative and draws if winner cannot mate', async () => {
  for (const [fen, winner] of [['7k/8/8/8/8/8/8/R3K3 w - - 0 1', null], ['7k/r7/8/8/8/8/8/4K3 w - - 0 1', 'b']]) {
    const { env, host } = await room('1+0'); setPosition(env, host.code, fen);
    const row = env.DB.rows.get(host.code), game = JSON.parse(row.data);
    game.activeSince = Date.now() - 61000; row.data = JSON.stringify(game);
    const result = await api(env, `/games/${host.code}`, { token: host.token });
    assert.deepEqual(result.data.result, { winner, reason: 'timeout' }); assert.equal(result.data.remaining.w, 0);
  }
});

test('concurrent duplicate moves are committed once', async () => {
  const { move } = await room();
  const responses = await Promise.all([move('w', 'e2', 'e4'), move('w', 'e2', 'e4')]);
  assert.deepEqual(responses.map(r => r.status).sort(), [200, 409]);
});
