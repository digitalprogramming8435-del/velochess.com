import test from 'node:test';
import assert from 'node:assert/strict';
import {database} from './helpers/d1.js';
import {handleApi} from '../server/api.js';
import {digest,randomHex} from '../server/http.js';

async function identity(env,name,rating=800){
 const id=crypto.randomUUID(),token=randomHex();
 await env.DB.prepare('INSERT INTO users (id,email,email_verified,password_hash,google_sub,username,username_key,rating,games_played,rating_revision,created_at) VALUES (?,?,1,NULL,NULL,?,?,?,5,0,?)').bind(id,name+'@example.invalid',name,name.toLowerCase(),rating,Date.now()).run();
 await env.DB.prepare('INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES (?,?,?,?)').bind(await digest(token),id,Date.now()+86400000,Date.now()).run();
 return{id,rating,cookie:'__Host-velo_session='+token};
}
async function enqueue(env,user){return env.DB.prepare('INSERT INTO matchmaking (user_id,time_control,rated,rating,last_seen,created_at,game_code,color) VALUES (?,\'10+0\',1,?,?,?,NULL,NULL)').bind(user.id,user.rating,Date.now(),Date.now()).run()}
async function start(env,user){const response=await handleApi(new Request('https://velo.test/api/matchmaking',{method:'POST',headers:{Cookie:user.cookie,'Content-Type':'application/json'},body:JSON.stringify({timeControl:'10+0',rated:true})}),env);return{status:response.status,data:await response.json()}}
function beforeFirstBatch(env,mutation){const original=env.DB.batch.bind(env.DB);let first=true;env.DB.batch=async statements=>{if(first){first=false;await mutation()}return original(statements)}}

for(const scenario of ['cancelled opponent','changed time control','changed rated choice','expired heartbeat','cancelled requester'])test(`match claim refuses ${scenario} after candidate selection without orphan games`,async()=>{
 const env={DB:database()},a=await identity(env,'Claim.Alpha'),b=await identity(env,'Claim.Beta');
 await enqueue(env,b);
 beforeFirstBatch(env,async()=>{
  if(scenario==='cancelled opponent')await env.DB.prepare('DELETE FROM matchmaking WHERE user_id=?').bind(b.id).run();
  if(scenario==='changed time control')await env.DB.prepare('UPDATE matchmaking SET time_control=? WHERE user_id=?').bind('3+0',b.id).run();
  if(scenario==='changed rated choice')await env.DB.prepare('UPDATE matchmaking SET rated=0 WHERE user_id=?').bind(b.id).run();
  if(scenario==='expired heartbeat')await env.DB.prepare('UPDATE matchmaking SET last_seen=? WHERE user_id=?').bind(Date.now()-16000,b.id).run();
  if(scenario==='cancelled requester')await env.DB.prepare('DELETE FROM matchmaking WHERE user_id=?').bind(a.id).run();
 });
 const result=await start(env,a);
 assert.equal(result.status,200);
 assert.notEqual(result.data.status,'matched');
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM games').first()).n,0);
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM game_players').first()).n,0);
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM matchmaking WHERE game_code IS NOT NULL').first()).n,0);
});

test('a cancelled closest candidate is skipped and the next eligible player is matched atomically',async()=>{
 const env={DB:database()},a=await identity(env,'Fallback.Alpha'),b=await identity(env,'Fallback.Beta',805),c=await identity(env,'Fallback.Gamma',850);
 await enqueue(env,b);await enqueue(env,c);
 beforeFirstBatch(env,()=>env.DB.prepare('DELETE FROM matchmaking WHERE user_id=?').bind(b.id).run());
 const result=await start(env,a);
 assert.equal(result.status,200);assert.equal(result.data.status,'matched');
 const players=Object.values(result.data.game.state.players).map(p=>p.userId);
 assert.ok(players.includes(a.id));assert.ok(players.includes(c.id));assert.ok(!players.includes(b.id));
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM games').first()).n,1);
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM game_players').first()).n,2);
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM matchmaking WHERE game_code=?').bind(result.data.game.code).first()).n,2);
});

test('cancellation returns a committed match instead of hiding or cancelling an active game',async()=>{
 const env={DB:database()},a=await identity(env,'Cancel.Alpha'),b=await identity(env,'Cancel.Beta');
 assert.equal((await start(env,a)).data.status,'waiting');
 const matched=await start(env,b);assert.equal(matched.data.status,'matched');
 const response=await handleApi(new Request('https://velo.test/api/matchmaking',{method:'DELETE',headers:{Cookie:a.cookie}}),env);
 const result=await response.json();assert.equal(response.status,200);assert.equal(result.status,'matched');assert.equal(result.game.code,matched.data.game.code);
 assert.equal((await env.DB.prepare('SELECT COUNT(*) AS n FROM game_players').first()).n,2);
 assert.equal(JSON.parse((await env.DB.prepare('SELECT data FROM games WHERE code=?').bind(result.game.code).first()).data).status,'active');
});
