import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { canPossiblyMate, remainingMs, snapshotClock } from '../public/game-logic.js';

test('timeout adjudication distinguishes mating possibilities from forceable mate', () => {
  const cases = [
    ['7k/8/8/8/8/8/8/4K3 w - - 0 1', false],
    ['7k/8/8/8/8/8/8/2B1K3 w - - 0 1', false],
    ['7k/8/8/8/8/8/8/2N1K3 w - - 0 1', false],
    ['7k/8/8/8/8/8/8/1NN1K3 w - - 0 1', true],
    ['7k/8/8/8/8/8/8/2BBK3 w - - 0 1', true],
    ['7k/8/8/8/8/4B3/8/2B1K3 w - - 0 1', false],
    ['5b1k/8/8/8/8/8/8/2B1K3 w - - 0 1', false],
    ['6bk/8/8/8/8/8/8/2B1K3 w - - 0 1', true],
    ['7k/p7/8/8/8/8/8/2N1K3 w - - 0 1', true],
    ['7k/8/8/8/8/8/P7/4K3 w - - 0 1', true],
  ];
  for (const [fen, expected] of cases) assert.equal(canPossiblyMate(new Chess(fen), 'w'), expected, fen);
});

test('clocks stop at zero and paused or unlimited controls do not tick', () => {
  assert.equal(remainingMs(10000, 1000, true, 5500), 5500);
  assert.equal(remainingMs(1000, 1000, true, 5500), 0);
  assert.equal(remainingMs(10000, 1000, false, 5500), 10000);
  assert.equal(remainingMs(10000, null, true, 5500), 10000);
  assert.equal(remainingMs(null, 1000, true, 5500), null);
  assert.equal(remainingMs(10000, 1000, true, 500), 10000);
});

test('move snapshots capture thinking time without ticking the opponent or retaining increment', () => {
  const clock = { w: 10000, b: 15000, since: 1000, increment: 2000 };
  const snapshot = snapshotClock(clock, 'w', true, 5500);
  assert.deepEqual(snapshot, { w: 5500, b: 15000, increment: 2000, started: true });
  assert.deepEqual(clock, { w: 10000, b: 15000, since: 1000, increment: 2000 });
  assert.deepEqual(snapshotClock(clock, 'w', false, 5500), { w: 10000, b: 15000, increment: 2000, started: false });
});
