import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {parseHTML} from 'linkedom';
import {Chess} from 'chess.js';
import {canPossiblyMate,remainingMs,snapshotClock} from '../public/game-logic.js';
import {PIECE_STYLES,pieceSvg} from '../public/pieces.js';
import {SOUND_PACKS,SOUND_PREVIEW_EVENTS,moveSoundEvent} from '../public/sound.js';

/** DOM simulation only: no browser, layout engine, audio hardware or network. */
function app({community=false,fetcher}={}) {
  const {window,document}=parseHTML(readFileSync(new URL('../public/index.html',import.meta.url),'utf8'));
  let active=document.body,hit=null,timerId=0;
  const timers=new Map(),storage=new Map(),captured=new Set(),sounds=[];
  Object.defineProperty(document,'activeElement',{get:()=>active});
  window.HTMLElement.prototype.focus=function(){active=this};
  window.HTMLElement.prototype.select=function(){active=this};
  window.HTMLElement.prototype.animate=function(){return{cancel(){},finished:Promise.resolve()}};
  window.HTMLElement.prototype.getBoundingClientRect=function(){return{x:0,y:0,width:64,height:64,left:0,top:0,right:64,bottom:64}};
  window.HTMLElement.prototype.setPointerCapture=function(id){captured.add(id)};
  window.HTMLElement.prototype.releasePointerCapture=function(id){captured.delete(id)};
  window.HTMLElement.prototype.hasPointerCapture=function(id){return captured.has(id)};
  // Linkedom models select options but omits the browser's value setter.
  Object.defineProperty(window.HTMLSelectElement.prototype,'value',{configurable:true,get(){return this.querySelector('option[selected]')?.getAttribute('value')??this.querySelector('option')?.getAttribute('value')??''},set(value){for(const option of this.querySelectorAll('option'))option.toggleAttribute('selected',option.getAttribute('value')===String(value))}});
  document.elementFromPoint=()=>hit;
  window.scrollTo=()=>{};
  const location={origin:'https://rook.example',pathname:'/',search:''};
  class QuietAudio{unlock(){return Promise.resolve(true)}play(...args){sounds.push(args)}preview(...args){sounds.push(['preview',...args])}}
  const sandbox={window,document,Chess,canPossiblyMate,remainingMs,snapshotClock,PIECE_STYLES,pieceSvg,SOUND_PACKS,SOUND_PREVIEW_EVENTS,moveSoundEvent,SoundEngine:QuietAudio,crypto:globalThis.crypto,URL,URLSearchParams,Blob,console,Date,Math,Promise,
    localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,val)=>storage.set(key,String(val))},
    navigator:{clipboard:{writeText:async()=>{}}},location,
    history:{replaceState(_a,_b,url){location.search=String(url).includes('?')?String(url).slice(String(url).indexOf('?')):''}},
    fetch:fetcher||(async()=>{throw Error('Unexpected network request in DOM test')}),
    setTimeout(fn,ms){const id=++timerId;timers.set(id,{fn,ms});return id},clearTimeout:id=>timers.delete(id),setInterval:()=>0,clearInterval:()=>{}};
  const context=vm.createContext(sandbox);if(community)vm.runInContext('globalThis.initCommunity=(()=>{'+readFileSync(new URL('../public/community.js',import.meta.url),'utf8').replace('export function initCommunity','function initCommunity')+';return initCommunity})();',context);
  vm.runInContext(readFileSync(new URL('../public/app.js',import.meta.url),'utf8').replace(/^import .*;\n/gm,''),context,{filename:'app.js',timeout:2000});
  const run=code=>vm.runInContext(code,context);
  const $=s=>document.querySelector(s);
  function emit(el,type,props={}){const e=new window.Event(type,{bubbles:true,cancelable:true});Object.assign(e,props);el.dispatchEvent(e);return e}
  function pointer(el,type,props={}){return emit(el,type,{button:0,pointerId:1,clientX:20,clientY:20,...props})}
  function flushTimers(maxMs=10){for(const[id,timer]of[...timers])if(timer.ms<=maxMs){timers.delete(id);timer.fn()}}
  return{window,document,run,$,emit,pointer,flushTimers,sounds,storage,setHit:el=>hit=el};
}

test('standard position has 64 correctly colored, labeled squares, including after flip',()=>{
  const a=app();
  assert.equal(a.document.querySelectorAll('[data-square]').length,64);
  assert(a.$('[data-square="a1"]').classList.contains('dark'));
  assert(a.$('[data-square="h1"]').classList.contains('light'));
  assert.match(a.$('[data-square="e1"]').getAttribute('aria-label'),/white king/);
  assert.match(a.$('[data-square="e8"]').getAttribute('aria-label'),/black king/);
  assert.equal(a.$('#board').firstElementChild.dataset.square,'a8');
  a.$('#flipBtn').click();
  assert.equal(a.$('#board').firstElementChild.dataset.square,'h1');
  assert(a.$('[data-square="h1"]').classList.contains('light'));
  assert.match(a.$('#bottomPlayer').textContent,/Black/);
});

test('default click-and-drag mode accepts captured-pointer taps and click-to-move',async()=>{
  const a=app(),board=a.$('#board'),e2=a.$('[data-square="e2"]');
  a.pointer(e2,'pointerdown');
  // The real browser retargets this event to the pointer-capturing board.
  a.pointer(board,'pointerup');
  assert.equal(a.run('selected'),'e2');
  assert(a.$('[data-square="e4"]').classList.contains('legal'));
  a.pointer(a.$('[data-square="e4"]'),'pointerup');
  await Promise.resolve();
  assert.equal(a.run('chess.get("e4").type'),'p');
  assert.equal(a.run('chess.get("e2")'),undefined);
  assert.equal(a.$('.move-san').textContent,'e4');
});

test('dragging a piece to its legal destination moves once and removes its ghost',async()=>{
  const a=app(),board=a.$('#board');
  a.pointer(a.$('[data-square="g1"]'),'pointerdown');
  a.pointer(board,'pointermove',{clientX:150,clientY:150});
  assert(a.$('.drag-ghost'));
  a.setHit(a.$('[data-square="f3"]'));
  a.pointer(board,'pointerup',{clientX:150,clientY:150});
  await Promise.resolve();
  assert.equal(a.run('chess.get("f3").type'),'n');
  assert.equal(a.run('chess.history().length'),1);
  assert.equal(a.$('.drag-ghost'),null);
});

test('keyboard movement remains available in drag-only gesture mode',async()=>{
  const a=app();a.run("prefs.input='drag'");
  a.emit(a.$('[data-square="d2"]'),'keydown',{key:'Enter'});
  assert.equal(a.run('selected'),'d2');
  a.emit(a.$('[data-square="d4"]'),'keydown',{key:'Enter'});
  await Promise.resolve();
  assert.equal(a.run('chess.get("d4").type'),'p');
});

test('all settings choices are present and selecting settings persists preferences',()=>{
  const a=app();
  a.run("showSettings('board')");
  assert.equal(a.document.querySelectorAll('[data-board]').length,11); // includes body theme
  a.$('[data-board="green"]').click();
  assert.equal(a.run('prefs.board'),'green');
  assert.equal(a.document.body.dataset.board,'green');
  a.run("showSettings('pieces')");
  assert.equal(a.document.querySelectorAll('[data-pieces]').length,12);
  a.$('[data-pieces="modern"]').click();
  assert.equal(a.run('prefs.pieces'),'modern');
  a.run("showSettings('sounds')");
  assert.equal(a.document.querySelectorAll('[data-sound]').length,13);
  for(const event of ['move','capture','check','end'])a.$(`[data-event="${event}"]`).click();
  assert.deepEqual(a.sounds.slice(-4).map(x=>x[0]),['move','capture','check','end']);
  a.run("showSettings('appearance')");
  assert.equal(a.document.querySelectorAll('[data-appearance]').length,5); // includes body
  a.$('[data-appearance="midnight"]').click();
  assert.equal(a.document.body.dataset.appearance,'midnight');
  assert.equal(JSON.parse(a.storage.get('rook.preferences')).appearance,'midnight');
});

test('Escape cancels promotion and resolves the pending move choice',async()=>{
  const a=app();
  const pending=a.run("choosePromotion('w')");
  assert.equal(a.document.querySelectorAll('[data-promote]').length,4);
  a.emit(a.document,'keydown',{key:'Escape'});
  const result=await Promise.race([pending,new Promise((_,reject)=>globalThis.setTimeout(()=>reject(Error('Promotion promise stayed unresolved after Escape')),100))]);
  assert.equal(result,null);
  assert.equal(a.$('#modalRoot').childElementCount,0);
});

test('settings rerenders preserve the original trigger for focus restoration',()=>{
  const a=app(),trigger=a.$('#settingsBtn');trigger.focus();trigger.click();a.flushTimers();
  a.$('[data-stab="pieces"]').focus();a.$('[data-stab="pieces"]').click();a.flushTimers();
  a.$('[data-pieces="modern"]').focus();a.$('[data-pieces="modern"]').click();a.flushTimers();
  a.emit(a.document,'keydown',{key:'Escape'});
  assert.equal(a.document.activeElement?.id,trigger.id);
});

test('join invitation input keeps autofocus after modal focus scheduling',()=>{
  const a=app();a.run("showJoin('ABCDEFGH')");a.flushTimers();
  assert.equal(a.document.activeElement?.id,'joinCode');
  assert.equal(a.$('#joinCode').getAttribute('maxlength'),'8');
});

test('unchanged online polling preserves selected pieces and pending new-game setup',()=>{
  const a=app();
  const state={code:'ABCD2345',revision:2,serverNow:Date.now(),pgn:'',fen:new Chess().fen(),timeControl:'10+0',status:'active',remaining:{w:600000,b:600000},activeSince:null,players:{w:{name:'You'},b:{name:'Friend'}},result:null,drawOffer:null};
  a.run(`connectRoom(${JSON.stringify({code:state.code,token:'host-test-token',color:'w',state})})`);
  a.run("onSquare('e2')");
  assert.equal(a.run('selected'),'e2');
  a.run('adoptRemote({...remote,serverNow:Date.now()+100})');
  assert.equal(a.run('selected'),'e2');
  assert(a.$('[data-square="e4"]').classList.contains('legal'));
  a.$('#newRoom').click();
  a.$('[data-time="5+0"]').click();
  assert.equal(a.$('#setupFields').hidden,false);
  assert.equal(a.run('setupTimeControl'),'5+0');
  assert.equal(a.run('timeControl'),'10+0');
  a.run("adoptRemote({...remote,revision:3,drawOffer:'b',serverNow:Date.now()})");
  assert.equal(a.$('#setupFields').hidden,false);
  assert.equal(a.run('setupTimeControl'),'5+0');
  assert.equal(a.run('selected'),'e2');
  a.run('adoptRemote({...remote,revision:1})');
  assert.equal(a.run('remote.revision'),3);
});

test('check glow and fallen king apply to the losing king for either color',()=>{
  const a=app();
  a.run("chess.load('rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3');result=currentResult();render()");
  assert(a.$('[data-square="e1"]').classList.contains('check'));
  assert(a.$('[data-square="e1"] .piece').classList.contains('fallen'));
  assert(!a.$('[data-square="e8"] .piece').classList.contains('fallen'));
  a.run("chess.load('rnbqkbnr/ppppp2p/5p2/6pQ/4P3/8/PPPP1PPP/RNB1KBNR b KQkq - 1 3');result=currentResult();render()");
  assert(a.$('[data-square="e8"]').classList.contains('check'));
  assert(a.$('[data-square="e8"] .piece').classList.contains('fallen'));
  assert(!a.$('[data-square="e1"] .piece').classList.contains('fallen'));
});

test('premoves are off by default and enabled queues project multiple future moves',async()=>{const a=app();assert.equal(a.run('prefs.premoves'),false);a.run("mode='online';online={code:'ABCD2345',color:'b',token:'x',offset:0};remote={code:'ABCD2345',revision:1,status:'active',timeControl:'10+0',pgn:chess.pgn(),players:{w:{name:'White'},b:{name:'Black'}},remaining:{w:600000,b:600000},activeSince:Date.now(),result:null};");a.pointer(a.$('[data-square="e7"]'),'pointerup');assert.equal(a.run('selected'),null);a.run("prefs.premoves=true;fetch=async(path,opts)=>{const data=JSON.parse(opts.body);return{ok:true,json:async()=>({...remote,revision:remote.revision+1,serverNow:Date.now(),ownPremoves:data.moves||[]})}};");a.pointer(a.$('[data-square="e7"]'),'pointerdown');a.pointer(a.$('#board'),'pointerup');assert.equal(a.run('selected'),'e7');a.pointer(a.$('[data-square="e5"]'),'pointerup');await new Promise(resolve=>setTimeout(resolve,0));assert.equal(a.run('premoves.length'),1);assert.ok(a.$('[data-square="e5"]').classList.contains('premove-to'));await a.run("queuePremove('g8','f6')");assert.equal(a.run('premoves.length'),2);assert.match(a.$('#premoveStrip').textContent,/2 premoves queued/)});

test('account UI submits real credentials to the API and displays returned rating without browser-stored password',async()=>{const calls=[];let signedIn=false;const user={id:'user-id',email:'alpha@example.invalid',username:'Alpha.Player',rating:800,gamesPlayed:0,provisional:true};const a=app({community:true,fetcher:async(path,opts={})=>{calls.push([path,opts]);let body=path==='/api/auth/me'?{user:signedIn?user:null}:path==='/api/auth/config'?{googleClientId:null}:path==='/api/social/friends'?{friends:[],requests:[],sent:[]}:path==='/api/auth/login'?(signedIn=true,{user}):{};return{ok:true,status:200,json:async()=>body}}});await a.run('community.refresh()');a.$('#accountButton').click();a.$('#authEmail').value='alpha@example.invalid';a.$('#authPassword').value='My long private password';await a.$('#authForm').onsubmit({preventDefault(){}});assert.ok(calls.some(([p,o])=>p==='/api/auth/login'&&JSON.parse(o.body).password==='My long private password'));assert.match(a.$('#accountButton').textContent,/Alpha.Player/);assert.match(a.$('#accountButton').textContent,/800/);assert.ok(![...a.storage.values()].some(v=>v.includes('My long private password')));a.run('community.openOnline()');assert.equal(a.$('#ratedChoice').classList.contains('selected'),true);assert.ok(a.$('#findOpponent'))});


test('late stale game responses cannot replace the current premove queue',()=>{
  const a=app();
  a.run("prefs.premoves=true;mode='online';online={code:'ABCD2345',color:'b',offset:0};remote={code:'ABCD2345',revision:5};premoves=[{from:'e7',to:'e5',promotion:'q'},{from:'g8',to:'f6',promotion:'q'}];renderPremoveUI();");
  a.run("adoptRemote({code:'ABCD2345',revision:4,ownPremoves:[],serverNow:Date.now()})");
  assert.equal(a.run('remote.revision'),5);
  assert.equal(a.run('premoves.length'),2);
  assert.equal(a.run('premoves[0].from'),'e7');
  assert.match(a.$('#premoveStrip').textContent,/2 premoves queued/);
});

test('sound settings offer the original files as one default pack with all ten event previews',()=>{const a=app();assert.equal(a.run('prefs.sound'),'chesscom');a.run("showSettings('sounds')");assert.equal(a.document.querySelectorAll('[data-sound="chesscom"]').length,1);assert.equal(a.document.querySelectorAll('[data-event]').length,10);for(const[event]of SOUND_PREVIEW_EVENTS)a.$(`[data-event="${event}"]`).click();assert.deepEqual(a.sounds.slice(-10).map(x=>x[0]),SOUND_PREVIEW_EVENTS.map(([event])=>event));a.$('[data-preview="chesscom"]').click();assert.equal(a.sounds.at(-1)[0],'preview');assert.equal(a.sounds.at(-1)[1],'chesscom')});

test('illegal moves and low-time alerts use their dedicated cues without repeating the time warning',async()=>{const a=app();await a.run("tryMove('e2','e5')");assert.equal(a.sounds.at(-1)[0],'illegal');assert.equal(a.run('chess.history().length'),0);a.run('started=true;localClock.w=9000;localClock.since=Date.now();updateClocks();updateClocks()');assert.equal(a.sounds.filter(x=>x[0]==='lowTime').length,1)});

test('local castling and promotion trigger their uploaded event cues',async()=>{const a=app();a.run("chess.load('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');render()");await a.run("tryMove('e1','g1')");assert.equal(a.sounds.at(-1)[0],'castle');a.run("chess.load('8/P6k/8/8/8/8/8/7K w - - 0 1');result=null;selected=null;render()");const promoting=a.run("tryMove('a7','a8')");a.$('[data-promote="q"]').click();await promoting;assert.equal(a.sounds.at(-1)[0],'promote')});

test('connecting a newly matched online game plays the uploaded game-start cue once',()=>{const a=app();a.run("connectRoom({code:'ABCD2345',color:'w',state:{code:'ABCD2345',revision:0,status:'active',timeControl:'10+0',pgn:chess.pgn(),result:null,players:{w:{name:'White'},b:{name:'Black'}},remaining:{w:600000,b:600000},activeSince:Date.now(),serverNow:Date.now(),ownPremoves:[]}})");assert.equal(a.sounds.filter(s=>s[0]==='start').length,1)});
