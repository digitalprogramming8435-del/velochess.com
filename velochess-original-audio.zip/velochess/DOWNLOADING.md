# VELOCHESS source download

This archive includes the chess application, twelve piece sets, ten recorded wooden sound packs, account and community APIs, rated matchmaking, multiple premoves, tests and database migrations.

Play now: https://velochess.grainyflour1.chatgpt.site

Install Node.js 22+ and run npm ci, npm test, then npm run build in the extracted velochess folder. The build generates a Cloudflare Worker in dist/server/index.js and a self-contained offline HTML for in-person chess. Online accounts and play require the server and D1 binding DB.

See SETUP.md for Google sign-in, custom-domain DNS, ratings, reconnect rules and deployment details. These external configurations are not automatically activated by downloading the source. The included hosting manifest omits the original project identity; create your own Site before deployment.

See public/LICENSES.md for artwork and recorded-audio licenses. Private account data, passwords, credentials, player sessions and the hosted database are not included.
