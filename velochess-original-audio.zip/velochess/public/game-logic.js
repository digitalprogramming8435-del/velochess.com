// A timeout only wins when the opponent can mate in some legal continuation.
export function canPossiblyMate(chess, color) {
  const pieces = chess.board().flat().filter(Boolean);
  const mine = pieces.filter(piece => piece.color === color && piece.type !== 'k');
  if (!mine.length) return false;
  if (mine.some(piece => ['p', 'q', 'r'].includes(piece.type))) return true;
  const theirs = pieces.filter(piece => piece.color !== color && piece.type !== 'k');
  if (mine.every(piece => piece.type === 'b')) {
    const squareColor = square => (square.charCodeAt(0) + Number(square[1])) % 2;
    const colors = new Set(mine.map(piece => squareColor(piece.square)));
    if (colors.size > 1) return true;
    const bishopColor = [...colors][0];
    return theirs.some(piece => piece.type !== 'b' || squareColor(piece.square) !== bishopColor);
  }
  if (mine.length === 1 && mine[0].type === 'n') return theirs.length > 0;
  return true;
}

export function remainingMs(value, since, ticking, now = Date.now()) {
  if (value == null) return null;
  return Math.max(0, value - (ticking && since != null ? Math.max(0, now - since) : 0));
}

export function snapshotClock(clock, turn, started, now = Date.now()) {
  return {
    w: remainingMs(clock.w, clock.since, started && turn === 'w', now),
    b: remainingMs(clock.b, clock.since, started && turn === 'b', now),
    increment: clock.increment,
    started,
  };
}
