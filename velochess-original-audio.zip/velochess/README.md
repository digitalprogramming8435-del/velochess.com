# VELOCHESS

A complete chess club with local chess, private online rooms, account-based rated/casual matchmaking, friends and direct/game chat.

- Twelve piece sets, with the original simple Velo set as default; ten board palettes and four website appearances.
- One default Chess.com Original sound pack uses the ten uploaded recordings unchanged, with dedicated move, capture, check, castling, promotion, premove, illegal, low-time, game-start and game-end cues. Twelve wooden alternatives remain selectable.
- Click/drag input, coordinates, SAN/PGN, legal moves, red check glow, falling checkmated kings and victory effects.
- Email/password accounts with salted scrypt hashing, expiring secure HttpOnly sessions, request-origin checks and server rate limits. Optional nonce-verified Google Identity Services after GOOGLE_CLIENT_ID is configured.
- Unique case-insensitive usernames containing only letters and dots.
- Real-player matchmaking using fresh queue heartbeats, nearest rating and atomic player claims. No fake opponents or automatic bots.
- Starting rating 800; first five rated games provisional. Official changes follow the requested gap rules. Draws never change ratings. A unique ledger applies results exactly once.
- Persistent friend requests with accept/decline, private friend chat, participant-only game chat, emoji picker and per-message/per-conversation deletion controls. Deleting for everyone redacts the stored message body; deleting for me hides only that participant's copy.
- Optional multiple premoves, off by default. The server executes up to ten queued legal moves at a 10 ms clock cost each, plus the control's increment.
- Server-adjudicated reconnect/abandonment deadlines by time control, move-by-move game review and PGN export.

## Build and test

Node.js 22+ is required. Run `npm ci`, `npm test`, `npm run build`, then `node scripts/validate.mjs`.

The build embeds frontend assets and download artifacts in a Cloudflare Worker at `dist/server/index.js`. It packages the source hosting manifest and generated Drizzle migrations. Bind D1 as `DB` and apply the tracked schema migrations before serving. See `SETUP.md` for external Google/domain configuration, rating rules and reconnect timing.

## Downloads

The published site serves a self-contained offline in-person game at `/downloads/velochess.html` and a sanitized source ZIP at `/downloads/velochess-source.zip`. Legacy download paths remain supported. Online accounts and multiplayer require the server; the offline HTML needs no installation.

The source ZIP excludes hosting identity, Git, dependencies, runtime data and credentials. Regenerate with `node scripts/package-source.mjs`.

## Verification limits

Automated rule, account, authorization, race, rating, DOM interaction and artifact checks are included. Managed browser control was unavailable during implementation, so visual layout and listening checks remain unperformed.

Artwork and audio credits are in `public/LICENSES.md`; embedded SVG sources and recorded contact samples are distributed with the application.
