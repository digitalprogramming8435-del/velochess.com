CREATE INDEX `conversation_hidden_lookup_idx` ON `conversation_hidden` (`conversation_key`,`before`);--> statement-breakpoint
CREATE INDEX `friendships_sender_idx` ON `friendships` (`sender_id`,`status`);--> statement-breakpoint
CREATE INDEX `friendships_receiver_idx` ON `friendships` (`receiver_id`,`status`);--> statement-breakpoint
CREATE INDEX `game_players_game_idx` ON `game_players` (`game_code`);--> statement-breakpoint
CREATE INDEX `matchmaking_pool_idx` ON `matchmaking` (`time_control`,`rated`,`last_seen`);--> statement-breakpoint
CREATE INDEX `message_hidden_lookup_idx` ON `message_hidden` (`user_id`,`message_id`);--> statement-breakpoint
CREATE INDEX `messages_conversation_idx` ON `messages` (`conversation_key`,`created_at`);