CREATE TABLE `auth_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `conversation_hidden` (
	`key` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`conversation_key` text NOT NULL,
	`before` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `friendships` (
	`id` text PRIMARY KEY NOT NULL,
	`pair_key` text NOT NULL,
	`sender_id` text NOT NULL,
	`receiver_id` text NOT NULL,
	`status` text NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `friendships_pair_key_unique` ON `friendships` (`pair_key`);--> statement-breakpoint
CREATE TABLE `game_players` (
	`user_id` text PRIMARY KEY NOT NULL,
	`game_code` text NOT NULL,
	`color` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `google_challenges` (
	`nonce_hash` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `matchmaking` (
	`user_id` text PRIMARY KEY NOT NULL,
	`time_control` text NOT NULL,
	`rated` integer NOT NULL,
	`rating` integer NOT NULL,
	`last_seen` integer NOT NULL,
	`created_at` integer NOT NULL,
	`game_code` text,
	`color` text
);
--> statement-breakpoint
CREATE TABLE `message_hidden` (
	`key` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`message_id` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`conversation_key` text NOT NULL,
	`sender_id` text NOT NULL,
	`recipient_id` text,
	`game_code` text,
	`body` text,
	`deleted` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rating_ledger` (
	`game_code` text PRIMARY KEY NOT NULL,
	`white_id` text NOT NULL,
	`black_id` text NOT NULL,
	`white_delta` integer NOT NULL,
	`black_delta` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`email_verified` integer DEFAULT 0 NOT NULL,
	`password_hash` text,
	`google_sub` text,
	`username` text,
	`username_key` text,
	`rating` integer DEFAULT 800 NOT NULL,
	`games_played` integer DEFAULT 0 NOT NULL,
	`rating_revision` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_email_unique` ON `users` (`email`);--> statement-breakpoint
CREATE UNIQUE INDEX `users_google_sub_unique` ON `users` (`google_sub`);--> statement-breakpoint
CREATE UNIQUE INDEX `users_username_key_unique` ON `users` (`username_key`);